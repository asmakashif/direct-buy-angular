import { Component, OnInit, OnChanges } from '@angular/core';

import { Hero } from './hero';
import { HeroService } from './hero.service';
import { HotTableRegisterer } from '@handsontable-pro/angular';

@Component({
    selector: 'app-heroes',
    templateUrl: './heroes.component.html',
    styleUrls: ['./heroes.component.scss'],
})
export class HeroesComponent implements OnInit {
    hotId: string = 'HeroesTable';
    selectedHero: Hero;
    heroes: Hero[];
    tableSettings: {};

    constructor(
        private heroService: HeroService,
        private hotRegisterer: HotTableRegisterer
    ) {}

    ngOnInit() {
        const that = this;

        this.getHeroes();
        this.tableSettings = {
            data: that.heroes,
            columns: [{ data: 'id' }, { data: 'name' }, { data: 'action' }],
            afterChange: (changes, src) => {
                console.log(changes, src);
            },
            beforeKeyDown: (event) => {
                var reg = /^\d+$/;
                if (!reg.test(event.key)) {
                    event.preventDefault();
                }
            },
        };
    }

    getHeroes(): void {
        this.heroService
            .getHeroes()
            .subscribe((heroes) => (this.heroes = heroes));
    }
}
