<?php
require 'cPanel.php';
$shopDB ='direcbuy_test';
$ip_server = $_SERVER['SERVER_ADDR'];
$cpanel = new CPANEL("brokeronline", "Default!@#123", $ip_server); // Connect to cPanel - only do this once.
  
// Create a new database.
$create_db = $cpanel->uapi(
    'Mysql', 'create_database',
    array(
        'name'    => $shopDB,
    )
);
if($create_db)
{
	echo 'success';
}
else
{
	echo 'failed';
}
?>